import os
import sys
import sqlite3
from werkzeug.security import check_password_hash

desktop_path = r'C:\Users\ijk11\Desktop\forceracing-app'
dbs = {
    'app': os.path.join(desktop_path, 'forceracing_app.db'),
    'web': os.path.join(desktop_path, 'forceracing.db')
}

expected_tables = {'users', 'tasks', 'cad_files', 'inquiries', 'task_notifications', 'leadership_requests'}

for key, db_file in dbs.items():
    print(f'=== Checking {key} DB: {db_file} ===')
    if not os.path.exists(db_file):
        print(f'ERROR: {db_file} does not exist!')
        continue
    
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()
    
    # Tables
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';")
    tables = [r[0] for r in cursor.fetchall()]
    print(f'Total tables: {len(tables)}, Names: {sorted(tables)}')
    missing_tables = expected_tables - set(tables)
    if missing_tables:
        print(f'WARNING: Missing tables: {missing_tables}')
    else:
        print('All 6 expected tables present!')
        
    # Row counts
    for tbl in sorted(tables):
        cursor.execute(f"SELECT COUNT(*) FROM {tbl}")
        count = cursor.fetchone()[0]
        print(f'  Table {tbl}: {count} rows')
        
    # Check Administrator
    cursor.execute("SELECT id, full_name, username, email, role, password_hash FROM users WHERE username = 'admin'")
    admin = cursor.fetchone()
    if admin:
        pwd_ok = check_password_hash(admin[5], 'Admin@2026')
        print(f'  Admin found: ID={admin[0]}, Name={admin[1]}, Username={admin[2]}, Email={admin[3]}, Role={admin[4]}')
        print(f'  Password verification for Admin@2026: {"MATCH (VALID)" if pwd_ok else "FAILED"}')
    else:
        print('  ERROR: Admin user not found!')
    
    conn.close()
