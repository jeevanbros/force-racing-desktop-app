"""
Automated Test for Network Status Toast & Offline Task Assignment Guard
Verifies base template, task dashboard, task creation form, and static asset definitions.
"""
import unittest
import os
from app import create_app
from database import init_db, seed_db
from config import Config

class OfflineNetworkStatusTestCase(unittest.TestCase):
    def setUp(self):
        import uuid
        self.test_db = os.path.join(os.path.dirname(__file__), f'test_db_net_{uuid.uuid4().hex[:8]}.db')
        self.orig_db_path = Config.DATABASE_PATH
        Config.DATABASE_PATH = self.test_db

        self.app = create_app({'TESTING': True, 'WTF_CSRF_ENABLED': False})
        self.client = self.app.test_client()
        with self.app.app_context():
            init_db()
            seed_db()

    def tearDown(self):
        Config.DATABASE_PATH = self.orig_db_path
        import gc
        gc.collect()
        if os.path.exists(self.test_db):
            try:
                os.remove(self.test_db)
            except Exception:
                pass

    def test_network_status_toast_in_templates(self):
        """Verify #network-status-toast exists on rendered pages."""
        # 1. Home page
        res = self.client.get('/')
        self.assertEqual(res.status_code, 200)
        html = res.get_data(as_text=True)
        self.assertIn('id="network-status-toast"', html)
        self.assertIn('id="network-status-dot"', html)
        self.assertIn('id="network-status-icon"', html)
        self.assertIn('id="network-status-message"', html)
        self.assertIn('id="network-status-close"', html)

        # 2. Login as Captain and check task create page
        self.client.post('/auth/login', data={'username': 'captain', 'password': 'Captain@2026'}, follow_redirects=True)
        task_res = self.client.get('/tasks/new')
        self.assertEqual(task_res.status_code, 200)
        task_html = task_res.get_data(as_text=True)
        self.assertIn('id="network-status-toast"', task_html)

    def test_css_and_js_contain_network_guard(self):
        """Verify style.css and main.js define network toast, offline indicator, and guard."""
        css_path = os.path.join(os.path.dirname(__file__), 'static', 'css', 'style.css')
        js_path = os.path.join(os.path.dirname(__file__), 'static', 'js', 'main.js')

        with open(css_path, 'r', encoding='utf-8') as f:
            css = f.read()
        self.assertIn('#network-status-toast', css)
        self.assertIn('.is-offline', css)
        self.assertIn('.is-online', css)
        self.assertIn('fr-pulse-offline', css)
        self.assertIn('.btn-shake', css)

        with open(js_path, 'r', encoding='utf-8') as f:
            js = f.read()
        self.assertIn('initNetworkStatusMonitor', js)
        self.assertIn('window.addEventListener(\'offline\'', js)
        self.assertIn('window.addEventListener(\'online\'', js)
        self.assertIn('Internet disconnected', js)
        self.assertIn('Please reconnect before assigning work', js)
        self.assertIn('triggerButtonShake', js)

if __name__ == '__main__':
    unittest.main()
