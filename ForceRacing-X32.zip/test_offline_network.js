// Automated Test: Offline & Network Disconnection Notification Guard
const fs = require('fs');
const assert = require('assert');

console.log('--- Testing Offline & Network Disconnection Notification Engine ---');

// 1. Read files
const baseHtml = fs.readFileSync('templates/base.html', 'utf8');
const styleCss = fs.readFileSync('static/css/style.css', 'utf8');
const mainJs = fs.readFileSync('static/js/main.js', 'utf8');

// 2. Validate HTML template
assert(baseHtml.includes('id="network-status-toast"'), 'base.html must contain #network-status-toast');
assert(baseHtml.includes('id="network-status-dot"'), 'base.html must contain #network-status-dot');
assert(baseHtml.includes('id="network-status-icon"'), 'base.html must contain #network-status-icon');
assert(baseHtml.includes('id="network-status-message"'), 'base.html must contain #network-status-message');
assert(baseHtml.includes('id="network-status-close"'), 'base.html must contain #network-status-close');
console.log('✓ base.html contains all required network toast elements');

// 3. Validate CSS styles
assert(styleCss.includes('#network-status-toast'), 'style.css must define #network-status-toast');
assert(styleCss.includes('.network-status-toast.is-visible'), 'style.css must define .is-visible state');
assert(styleCss.includes('.is-offline'), 'style.css must define .is-offline indicator state');
assert(styleCss.includes('.is-online'), 'style.css must define .is-online indicator state');
assert(styleCss.includes('fr-pulse-offline'), 'style.css must define pulse keyframes');
assert(styleCss.includes('fr-shake'), 'style.css must define button shake animation');
assert(styleCss.includes('.btn-shake'), 'style.css must define .btn-shake class');
console.log('✓ style.css contains all styling, states, and shake animation');

// 4. Validate JS logic and simulated browser events
class MockElement {
  constructor(id, tagName = 'div') {
    this.id = id;
    this.tagName = tagName;
    this.classList = new Set();
    this.classList.add = (...classes) => classes.forEach(c => this.classList[c] = true);
    this.classList.remove = (...classes) => classes.forEach(c => delete this.classList[c]);
    this.classList.contains = (c) => !!this.classList[c];
    this.style = {};
    this.textContent = '';
    this.attributes = {};
    this.listeners = {};
  }
  setAttribute(k, v) { this.attributes[k] = v; }
  getAttribute(k) { return this.attributes[k] || null; }
  addEventListener(event, fn) {
    if (!this.listeners[event]) this.listeners[event] = [];
    this.listeners[event].push(fn);
  }
  closest(sel) {
    return this;
  }
  querySelector(sel) {
    return new MockElement('sub', 'input');
  }
}

const listeners = {};
const mockWindow = {
  addEventListener: (event, fn) => {
    if (!listeners[event]) listeners[event] = [];
    listeners[event].push(fn);
  },
  location: { pathname: '/tasks/create' }
};

const elements = {
  'network-status-toast': new MockElement('network-status-toast'),
  'network-status-dot': new MockElement('network-status-dot'),
  'network-status-icon': new MockElement('network-status-icon'),
  'network-status-message': new MockElement('network-status-message'),
  'network-status-close': new MockElement('network-status-close')
};

const docListeners = {};
const mockDocument = {
  getElementById: (id) => elements[id] || null,
  addEventListener: (event, fn, useCapture) => {
    if (!docListeners[event]) docListeners[event] = [];
    docListeners[event].push(fn);
  }
};

const mockNavigator = {
  onLine: false
};

// Evaluate the Network Monitor logic in our test harness
const sandbox = {
  window: mockWindow,
  document: mockDocument,
  navigator: mockNavigator,
  setTimeout: setTimeout,
  clearTimeout: clearTimeout,
  console: console
};

const vm = require('vm');
vm.createContext(sandbox);

// Extract only initNetworkStatusMonitor and run in sandbox
const monitorCode = mainJs.slice(mainJs.indexOf('function initNetworkStatusMonitor'));
vm.runInContext(monitorCode + '\ninitNetworkStatusMonitor();', sandbox);

console.log('✓ initNetworkStatusMonitor initialized successfully');

// Test 4.1: Initial offline detection
const toast = elements['network-status-toast'];
assert(toast.classList.contains('is-offline'), 'Toast must have is-offline class when initialized offline');
assert(toast.classList.contains('is-visible'), 'Toast must have is-visible class');
assert.strictEqual(elements['network-status-icon'].textContent, '⚠️');
console.log('✓ Initial offline state triggers toast with ⚠️ indicator');

// Test 4.2: Online event
mockNavigator.onLine = true;
listeners['online'].forEach(fn => fn());
assert(toast.classList.contains('is-online'), 'Toast must have is-online class on online event');
assert(!toast.classList.contains('is-offline'), 'Toast must remove is-offline class');
assert.strictEqual(elements['network-status-icon'].textContent, '✓');
assert(elements['network-status-message'].textContent.includes('Internet reconnected'));
console.log('✓ Online event displays "✓ Internet reconnected" with green indicator');

// Test 4.3: Offline event
mockNavigator.onLine = false;
listeners['offline'].forEach(fn => fn());
assert(toast.classList.contains('is-offline'), 'Toast must set is-offline on offline event');
assert.strictEqual(elements['network-status-icon'].textContent, '⚠️');
assert(elements['network-status-message'].textContent.includes('Internet disconnected'));
console.log('✓ Offline event displays "Internet disconnected" with ⚠️ indicator');

// Test 4.4: Task assignment form submit guard while offline
let prevented = false;
let propagationStopped = false;
const submitEvent = {
  preventDefault: () => { prevented = true; },
  stopImmediatePropagation: () => { propagationStopped = true; },
  target: {
    getAttribute: (attr) => attr === 'action' ? '/tasks/create' : null,
    querySelector: () => {
      const btn = new MockElement('submit-btn', 'button');
      btn.textContent = 'Assign Task';
      return btn;
    }
  }
};

// Trigger submit capture listener
docListeners['submit'].forEach(fn => fn(submitEvent));
assert(prevented, 'Offline submission must be prevented (preventDefault)');
assert(propagationStopped, 'Offline submission must stop propagation immediately');
assert(elements['network-status-message'].textContent.includes('Please reconnect before assigning work'));
console.log('✓ Offline task form submission intercepted, prevented, and triggers work assignment warning');

// Test 4.5: Click on task assignment button while offline
let clickPrevented = false;
let clickStopped = false;
const targetBtn = new MockElement('assign-btn', 'button');
targetBtn.textContent = 'Create New Task';
targetBtn.setAttribute('href', '/tasks/create');

const clickEvent = {
  preventDefault: () => { clickPrevented = true; },
  stopImmediatePropagation: () => { clickStopped = true; },
  target: {
    closest: () => targetBtn
  }
};

docListeners['click'].forEach(fn => fn(clickEvent));
assert(clickPrevented, 'Click on task assignment action while offline must be prevented');
assert(clickStopped, 'Click on task assignment action while offline must stop propagation');
assert(elements['network-status-message'].textContent.includes('Please reconnect before assigning work'));
console.log('✓ Click on task assignment button while offline intercepted and guarded');

console.log('====================================================');
console.log('ALL NETWORK STATUS & OFFLINE GUARD TESTS PASSED! 🚀');
console.log('====================================================');
