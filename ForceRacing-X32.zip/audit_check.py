import sqlite3
import os

db1_path = r"C:\Users\ijk11\Desktop\forceracing-app\forceracing_app.db"
db2_path = r"C:\Users\ijk11\Desktop\forceracing-app\forceracing.db"

conn1 = sqlite3.connect(db1_path)
conn2 = sqlite3.connect(db2_path)

c1 = conn1.cursor()
c2 = conn2.cursor()

c1.execute("SELECT name, sql FROM sqlite_master WHERE type='table' ORDER BY name")
s1 = c1.fetchall()

c2.execute("SELECT name, sql FROM sqlite_master WHERE type='table' ORDER BY name")
s2 = c2.fetchall()

print("Schema Match Check:")
mismatch = False
if len(s1) != len(s2):
    print(f"Table count mismatch: {len(s1)} vs {len(s2)}")
    mismatch = True

for (t1, sql1), (t2, sql2) in zip(s1, s2):
    if t1 != t2:
        print(f"Table name mismatch: {t1} vs {t2}")
        mismatch = True
    else:
        # Check pragma table_info
        c1.execute(f"PRAGMA table_info('{t1}')")
        cols1 = c1.fetchall()
        c2.execute(f"PRAGMA table_info('{t2}')")
        cols2 = c2.fetchall()
        if cols1 != cols2:
            print(f"Column mismatch in {t1}:")
            print("  app.db:", cols1)
            print("  web.db:", cols2)
            mismatch = True

if not mismatch:
    print("ALL TABLES AND COLUMNS MATCH 100% PERFECTLY!")

conn1.close()
conn2.close()
