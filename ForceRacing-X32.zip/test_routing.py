"""
Force Racing Dynamic Dual-Database Routing Test Suite
"""
import unittest
import os
import sys

sys.path.insert(0, r'C:\Users\ijk11\Desktop\forceracing-app')
from config import Config
from database import get_db, close_db
from app import create_app

class ForceRacingRoutingTestCase(unittest.TestCase):
    def test_direct_routing_paths(self):
        """Test get_db('app') and get_db('web') resolve to distinct database files."""
        db_app = get_db('app')
        cursor = db_app.cursor()
        cursor.execute("PRAGMA database_list;")
        app_db_files = [row[2] for row in cursor.fetchall() if row[1] == 'main']
        db_app.close()

        db_web = get_db('web')
        cursor = db_web.cursor()
        cursor.execute("PRAGMA database_list;")
        web_db_files = [row[2] for row in cursor.fetchall() if row[1] == 'main']
        db_web.close()

        self.assertEqual(os.path.abspath(app_db_files[0]), os.path.abspath(Config.APP_DATABASE_PATH))
        self.assertEqual(os.path.abspath(web_db_files[0]), os.path.abspath(Config.WEB_DATABASE_PATH))
        self.assertNotEqual(os.path.abspath(app_db_files[0]), os.path.abspath(web_db_files[0]))

    def test_request_context_routing(self):
        """Test routing within Flask request contexts via query params and headers."""
        flask_app = create_app({'TESTING': True})

        with flask_app.test_request_context('/'):
            conn_default = get_db()
            cur = conn_default.cursor()
            cur.execute("PRAGMA database_list;")
            default_file = [row[2] for row in cur.fetchall() if row[1] == 'main'][0]
            self.assertEqual(os.path.abspath(default_file), os.path.abspath(Config.APP_DATABASE_PATH))

        with flask_app.test_request_context('/?db=web'):
            conn_web = get_db()
            cur = conn_web.cursor()
            cur.execute("PRAGMA database_list;")
            web_file = [row[2] for row in cur.fetchall() if row[1] == 'main'][0]
            self.assertEqual(os.path.abspath(web_file), os.path.abspath(Config.WEB_DATABASE_PATH))

        with flask_app.test_request_context('/', headers={'X-Client-Type': 'web'}):
            conn_header = get_db()
            cur = conn_header.cursor()
            cur.execute("PRAGMA database_list;")
            header_file = [row[2] for row in cur.fetchall() if row[1] == 'main'][0]
            self.assertEqual(os.path.abspath(header_file), os.path.abspath(Config.WEB_DATABASE_PATH))

if __name__ == '__main__':
    unittest.main()
