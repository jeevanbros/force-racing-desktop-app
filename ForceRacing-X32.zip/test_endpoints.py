"""
Force Racing API Endpoints Test Suite
Tests GET /api/inquiries, GET /api/crew, GET /api/tasks,
GET /api/export/excel, and POST /api/inquiries with both ?db=app and ?db=web.
"""
import unittest
import sys
import os

sys.path.insert(0, r"C:\Users\ijk11\Desktop\forceracing-app")
from app import create_app
from database import init_db, seed_db, get_db
from config import Config

class ForceRacingApiEndpointsTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        for db_path in [Config.APP_DATABASE_PATH, Config.WEB_DATABASE_PATH]:
            init_db(db_path)
            seed_db()

    def setUp(self):
        self.app = create_app({'TESTING': True, 'WTF_CSRF_ENABLED': False})
        self.client = self.app.test_client()

    def test_get_inquiries_both_dbs(self):
        """Test GET /api/inquiries returns JSON array for both ?db=app and ?db=web."""
        for db in ['app', 'web']:
            res = self.client.get(f'/api/inquiries?db={db}')
            self.assertEqual(res.status_code, 200)
            data = res.get_json()
            self.assertEqual(data['status'], 'success')
            self.assertEqual(data['database'], db)
            self.assertIn('inquiries', data)

    def test_get_crew_both_dbs(self):
        """Test GET /api/crew returns active crew roster for both ?db=app and ?db=web."""
        for db in ['app', 'web']:
            res = self.client.get(f'/api/crew?db={db}')
            self.assertEqual(res.status_code, 200)
            data = res.get_json()
            self.assertEqual(data['status'], 'success')
            self.assertEqual(data['database'], db)
            self.assertIn('crew', data)
            self.assertGreater(data['count'], 0)

    def test_get_tasks_both_dbs(self):
        """Test GET /api/tasks returns operational tasks for both ?db=app and ?db=web."""
        for db in ['app', 'web']:
            res = self.client.get(f'/api/tasks?db={db}')
            self.assertEqual(res.status_code, 200)
            data = res.get_json()
            self.assertEqual(data['status'], 'success')
            self.assertEqual(data['database'], db)
            self.assertIn('tasks', data)
            self.assertGreater(data['count'], 0)

    def test_export_excel_both_dbs(self):
        """Test GET /api/export/excel returns Excel attachment for both ?db=app and ?db=web."""
        for db in ['app', 'web']:
            res = self.client.get(f'/api/export/excel?db={db}')
            self.assertEqual(res.status_code, 200)
            self.assertIn('application/vnd.openxmlformats', res.content_type)
            self.assertGreater(len(res.data), 1000)

    def test_post_inquiry_json_and_persistence(self):
        """Test POST /api/inquiries with JSON payload for both ?db=app and ?db=web."""
        for db in ['app', 'web']:
            payload = {
                'organization': f'SAE Partner {db.upper()}',
                'email': f'sponsor_{db}@saeindia.org',
                'name': f'SAE Lead {db}',
                'phone': '+91 9123456780',
                'tier': 'Platinum Partner',
                'message': f'Official test inquiry for {db} database.'
            }
            res = self.client.post(f'/api/inquiries?db={db}', json=payload)
            self.assertEqual(res.status_code, 201)
            data = res.get_json()
            self.assertEqual(data['status'], 'success')
            self.assertEqual(data['database'], db)
            inq_id = data['inquiry_id']

            # Verify persisted
            chk = self.client.get(f'/api/inquiries?db={db}')
            chk_data = chk.get_json()
            self.assertTrue(any(i['id'] == inq_id for i in chk_data['inquiries']))

    def test_post_inquiry_validation(self):
        """Test POST /api/inquiries rejects requests missing required fields."""
        res = self.client.post('/api/inquiries', json={'tier': 'Gold'})
        self.assertEqual(res.status_code, 400)
        data = res.get_json()
        self.assertEqual(data['status'], 'error')

if __name__ == '__main__':
    unittest.main()
