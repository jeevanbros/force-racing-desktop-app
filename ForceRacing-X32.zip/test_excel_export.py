"""
Force Racing Excel Export Test Suite
Verifies master Excel generation for both APP DB and WEB DB.
"""
import unittest
import os
import sys
import openpyxl

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import Config
from utils.sheets_sync import export_database_to_excel

class ForceRacingExcelExportTestCase(unittest.TestCase):
    def test_excel_export_app_db(self):
        """Verify Excel export from APP DB contains all required sheets and headers."""
        excel_app_default = export_database_to_excel(db_path=Config.APP_DATABASE_PATH)
        self.assertTrue(os.path.exists(excel_app_default))

        wb = openpyxl.load_workbook(excel_app_default)
        expected_sheets = ["Partnership Inquiries", "Crew Registry", "CAD Transmissions"]
        for s in expected_sheets:
            self.assertIn(s, wb.sheetnames)
        wb.close()

    def test_excel_export_custom_targets(self):
        """Verify exporting to custom filenames for both App and Web DBs."""
        app_custom_xlsx = os.path.join(Config.DATA_DIR, "ForceRacing_App_Database.xlsx")
        web_custom_xlsx = os.path.join(Config.DATA_DIR, "ForceRacing_Web_Database.xlsx")

        export_database_to_excel(filepath=app_custom_xlsx, db_path=Config.APP_DATABASE_PATH)
        export_database_to_excel(filepath=web_custom_xlsx, db_path=Config.WEB_DATABASE_PATH)

        expected_sheets = ["Partnership Inquiries", "Crew Registry", "CAD Transmissions"]
        for name, path in [("App DB Excel", app_custom_xlsx), ("Web DB Excel", web_custom_xlsx)]:
            self.assertTrue(os.path.exists(path))
            wb = openpyxl.load_workbook(path)
            for s in expected_sheets:
                self.assertIn(s, wb.sheetnames)
            wb.close()

    def test_excel_export_web_db(self):
        """Verify Excel export from WEB DB contains all required sheets."""
        excel_web = export_database_to_excel(db_path=Config.WEB_DATABASE_PATH)
        self.assertTrue(os.path.exists(excel_web))
        wb = openpyxl.load_workbook(excel_web)
        expected_sheets = ["Partnership Inquiries", "Crew Registry", "CAD Transmissions"]
        for s in expected_sheets:
            self.assertIn(s, wb.sheetnames)
        wb.close()

if __name__ == '__main__':
    unittest.main()
